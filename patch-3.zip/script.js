// DOM Elements
const views = {
    lobby: document.getElementById('lobby-view'),
    waiting: document.getElementById('waiting-view'),
    match: document.getElementById('match-view'),
    results: document.getElementById('results-view')
};

// Lobby UI Elements
const createNameInput = document.getElementById('create-name-input');
const createRoundsSelect = document.getElementById('create-rounds-select');
const createDiffSelect = document.getElementById('create-diff-select');
const createRoomBtn = document.getElementById('create-room-btn');
const joinNameInput = document.getElementById('join-name-input');
const joinRoomInput = document.getElementById('join-room-input');
const joinBtn = document.getElementById('join-btn');

// Waiting UI Elements
const displayRoomId = document.getElementById('display-room-id');
const copyBtn = document.getElementById('copy-btn');
const cancelWaitBtn = document.getElementById('cancel-wait-btn');

// Match UI Elements
const roundHeaderEl = document.getElementById('round-header');
const problemTitleEl = document.getElementById('problem-title');
const problemDiffEl = document.getElementById('problem-difficulty');
const problemDescEl = document.getElementById('problem-desc');
const problemExamplesEl = document.getElementById('problem-examples');

const runBtn = document.getElementById('run-btn');
const submitBtn = document.getElementById('submit-btn');
const rematchBtn = document.getElementById('rematch-btn');
const countdownEl = document.getElementById('countdown');
const opponentStatusEl = document.getElementById('opponent-status');
const playerScoreEl = document.getElementById('player-score');
const codeEditor = document.getElementById('code-editor');
const consoleEl = document.getElementById('output-console');
const playerNameEl = document.getElementById('player-name');
const opponentNameEl = document.getElementById('opponent-name');

// Results UI Elements
const resultTitle = document.getElementById('result-title');
const finalPlayerScore = document.getElementById('final-player-score');
const finalTime = document.getElementById('final-time');
const finalOpponentStatus = document.getElementById('final-opponent-status');

// State
const socket = io();
let matchTimer;
let timeRemaining = 15 * 60; // 15 minutes in seconds
let currentScore = 1500; // Start with max points, decays over time
let matchActive = false;
let myName = '';

// View Navigation
function switchView(viewName) {
    Object.values(views).forEach(v => v.classList.remove('active'));
    views[viewName].classList.add('active');
}

// Format Time (MM:SS)
function formatTime(seconds) {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
}

// Timer Logic
function updateTimerDisplay() {
    countdownEl.innerText = formatTime(timeRemaining);
    if (timeRemaining <= 60) {
        countdownEl.classList.add('danger');
    } else {
        countdownEl.classList.remove('danger');
    }
}

// --- SOCKET.IO EVENTS ---

socket.on('errorMsg', (msg) => {
    alert(msg);
});

// Room Creation Success
socket.on('roomCreated', (roomId) => {
    displayRoomId.innerText = roomId;
    switchView('waiting');
});

// Match or Round Started
socket.on('roundStart', ({ players, timeRemaining: tr, currentRound, totalRounds, question }) => {
    timeRemaining = tr;
    currentScore = 1500;
    matchActive = true;
    updateTimerDisplay();

    // Setup Problem Data
    roundHeaderEl.innerText = `Round ${currentRound}/${totalRounds}`;
    problemTitleEl.innerText = question.title;
    problemDiffEl.innerText = question.difficulty;
    problemDiffEl.className = `difficulty ${question.difficulty.toLowerCase()}`;
    problemDescEl.innerHTML = question.desc;
    problemExamplesEl.innerHTML = question.examples;
    codeEditor.value = question.template;

    // Reset Console
    consoleEl.style.display = 'none';

    // Setup player info
    const me = players.find(p => p.id === socket.id);
    const opp = players.find(p => p.id !== socket.id);

    if (me) {
        playerNameEl.innerText = me.name;
        playerScoreEl.innerText = `${me.score} pts`;
    }

    if (opp) {
        opponentNameEl.innerText = opp.name;
        opponentStatusEl.innerText = opp.state || 'Waiting...';
    }

    switchView('match');
});

// Time Sync
socket.on('timeUpdate', (tr) => {
    timeRemaining = tr;
    updateTimerDisplay();

    // Score decays slightly every 3 seconds locally
    if (timeRemaining % 3 === 0 && currentScore > 100 && matchActive) {
        currentScore -= 2;
        playerScoreEl.innerText = `${currentScore} pts`;
    }
});

// Opponent Updates
socket.on('opponentStatus', (state) => {
    opponentStatusEl.innerText = state.text;
    opponentStatusEl.style.color = state.color;
});

socket.on('opponentScore', (score) => {
    // Optionally visualize opponent score dropping
});

// Match End Broadcast
socket.on('matchEnded', ({ outcome, finalScores, winnerId }) => {
    // Show total scores
    const myScore = finalScores[socket.id] || currentScore;
    const oppId = Object.keys(finalScores).find(id => id !== socket.id);
    const oppScore = oppId ? finalScores[oppId] : 0;

    // Determine status text based on winner ID
    let oppStatus = 'Finished';
    let myOutcome = outcome || 'Match Ended';

    if (winnerId === socket.id) {
        oppStatus = `Defeated (${oppScore} pts)`;
        myOutcome = outcome && outcome.includes('Time Up') ? 'Time Up - Victory!' : 'Match Victory!';
    } else if (winnerId) {
        oppStatus = `Winner! (${oppScore} pts)`;
        myOutcome = outcome && outcome.includes('Time Up') ? 'Time Up - Defeat' : 'Match Defeat...';
    } else {
        oppStatus = `Tie (${oppScore} pts)`;
        myOutcome = outcome && outcome.includes('Time Up') ? 'Time Up - Tie!' : 'Match Tie!';
    }

    endMatch(myOutcome, myScore, oppStatus);
});

// Round End Broadcast
socket.on('roundEnded', ({ winnerName, roundScore, nextRoundStartsIn }) => {
    endMatch(`Round Over!`, roundScore, `Winner: ${winnerName}`, true, nextRoundStartsIn);
});

socket.on('opponentDisconnected', () => {
    if (matchActive) {
        endMatch('Victory! (Disconnect)', currentScore, 'Disconnected');
    }
});

socket.on('errorMsg', (msg) => {
    alert(msg);
    switchView('lobby');
});

// Broadcast Typing Status
let typingTimer;
codeEditor.addEventListener('input', () => {
    if (!matchActive) return;
    socket.emit('statusUpdate', { text: 'Typing...', color: 'var(--accent-blue)' });

    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        socket.emit('statusUpdate', { text: 'Thinking...', color: 'var(--text-secondary)' });
    }, 2000);
});

// End Match Handlers
function endMatch(outcome, fScore = currentScore, oppStatus = 'Finished', isRoundOver = false, nextRoundStartsIn = 0) {
    matchActive = false;

    // Populate Results
    resultTitle.innerText = outcome;

    // Reset classes
    resultTitle.style.background = '';
    resultTitle.style.webkitBackgroundClip = '';
    resultTitle.style.backgroundClip = '';
    resultTitle.style.color = 'var(--text-primary)';

    if (outcome.includes('Victory') || outcome.includes('Winner')) {
        resultTitle.style.background = 'linear-gradient(135deg, var(--accent-blue), var(--accent-green))';
        resultTitle.style.webkitBackgroundClip = 'text';
        resultTitle.style.color = 'transparent';
        createConfetti();
    } else if (outcome.includes('Over') && !outcome.includes('Defeat')) {
        resultTitle.style.color = '#ffb700'; // Tie/Neutral Round Over
    } else {
        resultTitle.style.background = 'linear-gradient(135deg, var(--accent-red), #ff8800)';
        resultTitle.style.webkitBackgroundClip = 'text';
        resultTitle.style.color = 'transparent';
    }

    finalPlayerScore.innerText = fScore;
    finalOpponentStatus.innerText = oppStatus;

    if (isRoundOver) {
        finalTime.innerText = `Next round starts in ${nextRoundStartsIn}s...`;

        // Visual countdown for the next round
        let localCd = nextRoundStartsIn;
        const intv = setInterval(() => {
            localCd--;
            if (localCd > 0 && !matchActive) {
                finalTime.innerText = `Next round starts in ${localCd}s...`;
            } else {
                clearInterval(intv);
            }
        }, 1000);

    } else {
        finalTime.innerText = formatTime((15 * 60) - timeRemaining);
    }

    setTimeout(() => {
        switchView('results');
    }, 500);
}

// Basic Confetti logic for winner
function createConfetti() {
    const container = document.getElementById('confetti-container');
    container.innerHTML = '';
    const colors = ['#00e1ff', '#00ff88', '#ffffff'];

    for (let i = 0; i < 50; i++) {
        const conf = document.createElement('div');
        conf.style.position = 'absolute';
        conf.style.width = '10px';
        conf.style.height = '10px';
        conf.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        conf.style.left = Math.random() * 100 + '%';
        conf.style.top = '-10px';
        conf.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';

        const duration = Math.random() * 3 + 2;
        const delay = Math.random() * 2;

        conf.animate([
            { transform: 'translate3d(0,0,0) rotate(0deg)', opacity: 1 },
            { transform: `translate3d(${Math.random() * 100 - 50}px, 100vh, 0) rotate(${Math.random() * 360}deg)`, opacity: 0 }
        ], {
            duration: duration * 1000,
            delay: delay * 1000,
            easing: 'cubic-bezier(.37,0,.63,1)',
            fill: 'forwards'
        });

        container.appendChild(conf);
    }
}

// --- LOBBY LOGIC ---

createRoomBtn.addEventListener('click', () => {
    console.log("Create room clicked");
    myName = createNameInput.value.trim();
    console.log("Name:", myName);
    if (myName === '') {
        console.log("Empty name, aborting");
        createNameInput.style.borderColor = 'var(--accent-red)';
        setTimeout(() => createNameInput.style.borderColor = 'var(--border-color)', 500);
        return;
    }

    // Generate Room ID and Emit
    const roomId = Math.random().toString(36).substring(2, 8).toUpperCase();
    const rounds = createRoundsSelect.value;
    const difficulty = createDiffSelect.value;
    console.log("Emitting createRoom event with data:", { name: myName, roomId, rounds, difficulty });
    socket.emit('createRoom', { name: myName, roomId, rounds, difficulty });
});

copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(displayRoomId.innerText);
    const oldText = copyBtn.innerText;
    copyBtn.innerText = 'Copied!';
    setTimeout(() => copyBtn.innerText = oldText, 2000);
});

cancelWaitBtn.addEventListener('click', () => {
    window.location.reload();
});

joinBtn.addEventListener('click', () => {
    console.log("Join room clicked");
    myName = joinNameInput.value.trim();
    const roomId = joinRoomInput.value.trim();

    if (myName === '' || roomId === '') {
        if (myName === '') joinNameInput.style.borderColor = 'var(--accent-red)';
        if (roomId === '') joinRoomInput.style.borderColor = 'var(--accent-red)';
        setTimeout(() => {
            joinNameInput.style.borderColor = 'var(--border-color)';
            joinRoomInput.style.borderColor = 'var(--border-color)';
        }, 500);
        return;
    }

    socket.emit('joinRoom', { name: myName, roomId });
});

createNameInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') createRoomBtn.click(); });
joinRoomInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') joinBtn.click(); });

// Code Evaluation Logic
function evaluateCode(isSubmit = false) {
    if (!matchActive) return;

    const btn = isSubmit ? submitBtn : runBtn;
    const originalText = btn.innerText;
    btn.innerText = 'Evaluating...';
    btn.style.opacity = '0.7';

    // Disable buttons while running
    runBtn.disabled = true;
    submitBtn.disabled = true;

    window.lastEvaluationWasSubmit = isSubmit;
    const userCode = codeEditor.value;
    socket.emit('evaluateCode', { userCode });
}

// Listen for execution result from server
socket.on('evaluationResult', (data) => {
    runBtn.innerText = 'Run Code';
    runBtn.style.opacity = '1';
    runBtn.disabled = false;
    submitBtn.innerText = 'Submit';
    submitBtn.style.opacity = '1';
    submitBtn.disabled = false;
    const isSubmit = window.lastEvaluationWasSubmit;

    consoleEl.style.display = 'block';

    if (data.success) {
        consoleEl.innerText = isSubmit ? "All test cases passed!" : "Sample test cases passed!";
        consoleEl.className = 'output-console success';
        socket.emit('statusUpdate', { text: 'Tests Passed!', color: 'var(--accent-green)' });

        if (isSubmit) {
            socket.emit('submitSuccess', { score: currentScore });
        }
    } else {
        consoleEl.innerText = data.error || "Unknown Error";
        consoleEl.className = 'output-console error';

        const penalty = isSubmit ? 100 : 20;
        currentScore = Math.max(0, currentScore - penalty);
        playerScoreEl.innerText = `${currentScore} pts`;

        socket.emit('statusUpdate', { text: 'Test Failed', color: 'var(--accent-red)' });
        socket.emit('penalty', currentScore);

        countdownEl.classList.add('danger');
        setTimeout(() => {
            if (timeRemaining > 60) countdownEl.classList.remove('danger');
        }, 500);
    }
});

const lineNumbersEl = document.getElementById('line-numbers');

// Editor logic for Line Numbers and Indentation
function updateLineNumbers() {
    const lines = codeEditor.value.split('\n').length;
    lineNumbersEl.innerHTML = Array(lines).fill(0).map((_, i) => i + 1).join('<br>');
}

codeEditor.addEventListener('input', updateLineNumbers);

codeEditor.addEventListener('scroll', () => {
    lineNumbersEl.style.transform = `translateY(-${codeEditor.scrollTop}px)`;
});

codeEditor.addEventListener('keydown', function (e) {
    if (e.key === 'Tab') {
        e.preventDefault();
        const start = this.selectionStart;
        const end = this.selectionEnd;
        // set textarea value to: text before caret + 4 spaces + text after caret
        this.value = this.value.substring(0, start) +
            "    " + this.value.substring(end);
        // put caret at right position again
        this.selectionStart =
            this.selectionEnd = start + 4;
        updateLineNumbers();
    }
});

runBtn.addEventListener('click', () => {
    evaluateCode(false);
});

submitBtn.addEventListener('click', () => {
    evaluateCode(true);
});

rematchBtn.addEventListener('click', () => {
    window.location.reload();
});

// Init
createNameInput.focus();
updateLineNumbers();
